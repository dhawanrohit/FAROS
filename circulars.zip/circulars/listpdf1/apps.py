from django.apps import AppConfig


class ListpdfConfig(AppConfig):
    name = 'listpdf1'
